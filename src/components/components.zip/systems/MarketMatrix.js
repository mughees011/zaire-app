import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { ZaireCard, ZaireHeader } from './DesignSystem';

// High-fidelity SVG Grid visualizer
const QuantumGrid = () => (
  <div className="absolute inset-0 overflow-hidden opacity-20 pointer-events-none z-0">
    <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
          <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#fff" strokeWidth="0.5" opacity="0.2"/>
        </pattern>
        <pattern id="grid-large" width="100" height="100" patternUnits="userSpaceOnUse">
          <rect width="100" height="100" fill="url(#grid)" />
          <path d="M 100 0 L 0 0 0 100" fill="none" stroke="#00d4ff" strokeWidth="1" opacity="0.5"/>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#grid-large)" />
      
      {/* Scanning beam */}
      <motion.rect 
        width="100%" height="2" fill="#00d4ff" 
        animate={{ y: [0, 500, 0] }} 
        transition={{ duration: 4, ease: "linear", repeat: Infinity }} 
        style={{ filter: 'blur(2px)' }}
      />
    </svg>
  </div>
);

const MOCK_ASSETS = [
  { symbol: 'BTC', price: '64,230.00', change: '+2.4%', signal: 'STRONG BUY', score: 98, vol: '42B' },
  { symbol: 'ETH', price: '3,450.12', change: '-0.8%', signal: 'HOLD', score: 54, vol: '18B' },
  { symbol: 'SOL', price: '142.80', change: '+8.2%', signal: 'BREAKOUT', score: 92, vol: '6B' },
  { symbol: 'NVDA', price: '128.50', change: '+1.4%', signal: 'ACCUMULATE', score: 76, vol: '92B' },
];

export default function MarketMatrix() {
  const [assets, setAssets] = useState(MOCK_ASSETS);

  // GodX real-time price flickering
  useEffect(() => {
    const interval = setInterval(() => {
      setAssets(prev => prev.map(a => {
        if (Math.random() > 0.5) {
          const move = (Math.random() * 2 - 1).toFixed(2);
          const currentPrice = parseFloat(a.price.replace(',', ''));
          return { ...a, price: (currentPrice + parseFloat(move)).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}) };
        }
        return a;
      }));
    }, 800);
    return () => clearInterval(interval);
  }, []);

  return (
    <ZaireCard className="h-full relative" noPadding>
      <QuantumGrid />
      
      <ZaireHeader 
        title="Market Matrix" 
        icon={Activity} 
        rightElement={
          <div className="flex items-center gap-2 px-2 py-0.5 bg-[#00d4ff]/10 border border-[#00d4ff]/30 rounded text-[9px] font-mono text-[#00d4ff]">
            <span className="w-1.5 h-1.5 bg-[#00d4ff] rounded-full animate-ping"></span>
            QUANTUM ENGINE ACTIVE
          </div>
        }
      />

      <div className="flex-1 overflow-y-auto z-10 relative bg-black/40 backdrop-blur-md p-3 flex flex-col gap-3">
        {assets.map(asset => {
          const isUp = asset.change.startsWith('+');
          const color = isUp ? '#10b981' : '#ef4444';
          
          return (
            <div key={asset.symbol} className="bg-[#000000] border border-[#1f1f1f] hover:border-[#333] transition-colors rounded p-3 relative overflow-hidden group cursor-crosshair">
              {/* Dynamic colored accent bar */}
              <div className="absolute left-0 top-0 bottom-0 w-1" style={{ backgroundColor: color }}></div>
              
              <div className="flex justify-between items-start pl-2">
                <div className="flex flex-col">
                  <div className="flex items-center gap-2">
                    <span className="text-[16px] font-bold text-white tracking-widest">{asset.symbol}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#141414] border border-[#222] font-mono text-[#888]">VOL: {asset.vol}</span>
                  </div>
                  <span className="text-[22px] font-mono font-medium text-[#ededed] mt-1 flex items-center gap-1">
                    <DollarSign size={16} className="text-[#666]" />
                    {asset.price}
                  </span>
                </div>

                <div className="flex flex-col items-end gap-1">
                  <div className="flex items-center gap-1 px-2 py-1 rounded" style={{ backgroundColor: `${color}15`, color: color }}>
                    {isUp ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                    <span className="text-[11px] font-mono font-bold">{asset.change}</span>
                  </div>
                  
                  {/* AI Signal Block */}
                  <div className="mt-2 text-right">
                    <span className="text-[8px] uppercase tracking-widest text-[#666] block mb-0.5">Neural Signal</span>
                    <span className={`text-[10px] font-bold tracking-widest ${asset.score > 80 ? 'text-[#00d4ff]' : 'text-[#f59e0b]'}`}>
                      {asset.signal} [{asset.score}]
                    </span>
                  </div>
                </div>
              </div>

              {/* Advanced Signal Strength Bar */}
              <div className="mt-3 pl-2">
                <div className="h-1 w-full bg-[#111] rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full" 
                    style={{ backgroundColor: asset.score > 80 ? '#00d4ff' : '#f59e0b' }}
                    initial={{ width: 0 }}
                    animate={{ width: `${asset.score}%` }}
                    transition={{ duration: 1.5, type: 'spring' }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </ZaireCard>
  );
}
