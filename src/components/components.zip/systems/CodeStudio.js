import React, { useState } from 'react';
import { Code2, Play, Terminal, FolderTree, FileCode2 } from 'lucide-react';
import { ZaireCard, ZaireHeader, ZaireTabs, ZaireBadge } from './DesignSystem';
import { useZaireOS } from '../../engine/ZaireOSContext';

const MOCK_FILES = [
  { id: '1', name: 'ZaireAgent.ts', status: 'modified' },
  { id: '2', name: 'types.d.ts', status: 'saved' },
  { id: '3', name: 'vector_search.py', status: 'active' },
];

export default function CodeStudio() {
  const [activeTab, setActiveTab] = useState('editor');
  const { agents } = useZaireOS();

  const codeArchitect = agents.find(a => a.id === 'Code Architect');
  const isArchitectActive = codeArchitect?.status === 'ACTIVE' || codeArchitect?.status === 'EXECUTING';

  return (
    <ZaireCard className={`h-full ${isArchitectActive ? 'thinking' : ''}`} noPadding>
      <ZaireHeader 
        title="Engineering Studio" 
        icon={Code2} 
        rightElement={<ZaireBadge variant="info">TS/PY</ZaireBadge>}
      />

      <div className="flex-1 flex overflow-hidden bg-[#000000]">
        
        {/* Left Sidebar - File Tree */}
        <div className="w-40 border-r border-[#1f1f1f] bg-[#0a0a0a] flex flex-col">
          <div className="p-2 border-b border-[#1f1f1f] flex items-center gap-2">
            <FolderTree size={12} className="text-[#666]" />
            <span className="text-[9px] font-mono text-[#666] uppercase tracking-widest">Workspace</span>
          </div>
          <div className="flex-1 overflow-y-auto p-2 flex flex-col gap-1">
            {MOCK_FILES.map(f => (
              <div key={f.id} className={`flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer ${f.status === 'active' ? 'bg-[#141414] border border-[#222]' : 'hover:bg-[#111]'}`}>
                <FileCode2 size={10} className={f.status === 'active' ? 'text-[#00d4ff]' : 'text-[#555]'} />
                <span className={`text-[10px] font-mono truncate ${f.status === 'active' ? 'text-[#ededed]' : 'text-[#a0a0a0]'}`}>{f.name}</span>
                {f.status === 'modified' && <span className="w-1.5 h-1.5 rounded-full bg-[#f59e0b] ml-auto"></span>}
              </div>
            ))}
          </div>
        </div>

        {/* Main Editor Area */}
        <div className="flex-1 flex flex-col min-w-0">
          <ZaireTabs 
            activeTab={activeTab}
            onChange={setActiveTab}
            tabs={[
              { id: 'editor', label: 'vector_search.py' },
              { id: 'ast', label: 'AST Visualizer' }
            ]}
          />

          <div className="flex-1 p-3 overflow-y-auto font-mono text-[11px] leading-relaxed relative" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
            {/* Syntax Highlighting Mock */}
            <pre className="text-[#a0a0a0] m-0">
              <span className="text-[#c678dd]">import</span> numpy <span className="text-[#c678dd]">as</span> np{'\n'}
              <span className="text-[#c678dd]">from</span> typing <span className="text-[#c678dd]">import</span> List, Dict{'\n'}
              {'\n'}
              <span className="text-[#c678dd]">class</span> <span className="text-[#e5c07b]">VectorDatabase</span>:{'\n'}
              {'    '}<span className="text-[#c678dd]">def</span> <span className="text-[#61afef]">__init__</span>(self, dimensions: <span className="text-[#e5c07b]">int</span> = <span className="text-[#d19a66]">1536</span>):{'\n'}
              {'        '}self.dimensions = dimensions{'\n'}
              {'        '}self.index = []{'\n'}
              {'\n'}
              {'    '}<span className="text-[#c678dd]">def</span> <span className="text-[#61afef]">search</span>(self, query: List[<span className="text-[#e5c07b]">float</span>], k: <span className="text-[#e5c07b]">int</span> = <span className="text-[#d19a66]">5</span>) -&gt; List[Dict]:{'\n'}
              {'        '}<span className="text-[#5c6370]"># Perform fast cosine similarity</span>{'\n'}
              {'        '}vector = np.array(query){'\n'}
              {'        '}<span className="text-[#c678dd]">return</span> self._compute_similarity(vector, k){'\n'}
              {'\n'}
            </pre>
            
            {/* Blinking cursor if architect is active */}
            {isArchitectActive && (
              <div className="absolute mt-[-18px] ml-[310px] w-2 h-[14px] bg-[#00d4ff] animate-pulse"></div>
            )}
          </div>

          {/* Terminal / Output Split */}
          <div className="h-32 border-t border-[#1f1f1f] bg-[#0a0a0a] flex flex-col">
            <div className="flex items-center justify-between px-3 py-1.5 border-b border-[#1f1f1f] bg-[#000000]">
              <div className="flex items-center gap-2">
                <Terminal size={10} className="text-[#666]" />
                <span className="text-[9px] font-mono text-[#666] uppercase tracking-widest">Output</span>
              </div>
              <Play size={10} className="text-[#10b981] cursor-pointer hover:text-[#34d399]" />
            </div>
            <div className="flex-1 p-2 font-mono text-[10px] text-[#888] overflow-y-auto">
              {isArchitectActive ? (
                <>
                  <div className="text-[#00d4ff]">&gt; Compiling AST for vector_search.py...</div>
                  <div>&gt; Checking type hints... [OK]</div>
                  <div className="animate-pulse">_</div>
                </>
              ) : (
                <div className="text-[#555]">No active processes.</div>
              )}
            </div>
          </div>

        </div>
      </div>
    </ZaireCard>
  );
}
