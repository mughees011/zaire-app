import React, { useState } from 'react';
import { Target, Activity, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { ZaireCard, ZaireHeader, ZaireBadge, ZaireTabs } from './DesignSystem';
import { useZaireOS } from '../../engine/ZaireOSContext';

// Beautiful SVG Progress Ring
const ProgressRing = ({ radius, stroke, progress, color }) => {
  const normalizedRadius = radius - stroke * 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <svg height={radius * 2} width={radius * 2} className="transform -rotate-90">
      <circle
        stroke="#1f1f1f"
        fill="transparent"
        strokeWidth={stroke}
        r={normalizedRadius}
        cx={radius}
        cy={radius}
      />
      <motion.circle
        stroke={color}
        fill="transparent"
        strokeWidth={stroke}
        strokeLinecap="round"
        strokeDasharray={circumference + ' ' + circumference}
        initial={{ strokeDashoffset: circumference }}
        animate={{ strokeDashoffset }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        r={normalizedRadius}
        cx={radius}
        cy={radius}
      />
    </svg>
  );
};

export default function MissionBoard() {
  const [activeTab, setActiveTab] = useState('active');
  const { missions } = useZaireOS();

  const filteredMissions = missions.filter(m => {
    if (activeTab === 'active') return m.status === 'running' || m.status === 'waiting';
    if (activeTab === 'backlog') return m.status === 'todo';
    return m.status === 'done';
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case 'running': return <ZaireBadge variant="success" dot>RUNNING</ZaireBadge>;
      case 'waiting': return <ZaireBadge variant="warning">IDLE</ZaireBadge>;
      case 'todo': return <ZaireBadge variant="default">QUEUE</ZaireBadge>;
      case 'done': return <ZaireBadge variant="info">COMPLETE</ZaireBadge>;
      default: return null;
    }
  };

  // Calculate overall progress for the master ring
  const activeMissions = missions.filter(m => m.status === 'running' || m.status === 'waiting');
  const totalProgress = activeMissions.length === 0 
    ? 0 
    : activeMissions.reduce((acc, m) => acc + (m.progress || 0), 0) / activeMissions.length;

  return (
    <ZaireCard className="h-full" noPadding>
      <ZaireHeader 
        title="Mission Telemetry" 
        icon={Target} 
        rightElement={
          <div className="flex items-center gap-2 text-[9px] font-mono text-[#666] tracking-widest">
            <Activity size={10} className="text-[#10b981]" /> CLUSTER_NOMINAL
          </div>
        }
      />

      {/* Master Visual Dashboard */}
      <div className="h-28 bg-[#000000] border-b border-[#1f1f1f] flex items-center px-6 gap-6 relative overflow-hidden">
        {/* Background circuit pattern */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '16px 16px' }}></div>
        
        <div className="relative">
          <ProgressRing radius={35} stroke={4} progress={totalProgress} color="#10b981" />
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-[14px] font-mono font-bold text-[#ededed]">{Math.round(totalProgress)}%</span>
          </div>
        </div>

        <div className="flex flex-col gap-2 flex-1">
          <div className="text-[10px] font-mono text-[#666] uppercase tracking-widest">Active Operations</div>
          <div className="flex gap-4">
            <div className="flex flex-col">
              <span className="text-[18px] font-mono text-[#ededed] leading-none">{activeMissions.length}</span>
              <span className="text-[8px] font-mono text-[#555]">NODES</span>
            </div>
            <div className="w-[1px] bg-[#222]"></div>
            <div className="flex flex-col">
              <span className="text-[18px] font-mono text-[#10b981] leading-none">0</span>
              <span className="text-[8px] font-mono text-[#555]">BLOCKERS</span>
            </div>
          </div>
        </div>
      </div>

      <ZaireTabs 
        activeTab={activeTab}
        onChange={setActiveTab}
        tabs={[
          { id: 'active', label: 'Active Pipeline' },
          { id: 'backlog', label: 'Backlog' },
          { id: 'completed', label: 'Completed' }
        ]}
      />

      <div className="flex-1 overflow-y-auto bg-[#0a0a0a] p-3 flex flex-col gap-3">
        <AnimatePresence>
          {filteredMissions.length === 0 && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="h-full flex flex-col items-center justify-center text-[#444]">
              <CheckCircle2 size={24} className="mb-2 opacity-50 text-[#10b981]" />
              <div className="text-[11px] font-mono uppercase tracking-widest">Pipeline Clear</div>
            </motion.div>
          )}
          {filteredMissions.map(mission => (
            <motion.div 
              key={mission.id} 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={`bg-[#000000] border border-[#1f1f1f] rounded-lg p-3 relative flex gap-4 items-center group ${mission.status === 'done' ? 'opacity-50' : ''}`}
            >
              {/* Mission Individual Ring */}
              <div className="relative shrink-0">
                <ProgressRing 
                  radius={18} 
                  stroke={2} 
                  progress={mission.progress || 0} 
                  color={mission.status === 'done' ? '#3b82f6' : '#10b981'} 
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  {mission.status === 'done' ? (
                    <CheckCircle2 size={12} className="text-[#3b82f6]" />
                  ) : (
                    <span className="text-[8px] font-mono text-[#888]">{mission.progress || 0}%</span>
                  )}
                </div>
              </div>

              {/* Data Block */}
              <div className="flex-1 flex flex-col gap-1">
                <span className="text-[12px] font-medium text-[#ededed] font-sans truncate">{mission.title}</span>
                <div className="flex items-center gap-3">
                  <span className="text-[9px] font-mono text-[#666]">AGN: {mission.agent}</span>
                  <span className="text-[9px] font-mono text-[#666]">PRY: {mission.priority}</span>
                </div>
              </div>

              <div className="shrink-0">
                {getStatusBadge(mission.status)}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ZaireCard>
  );
}
