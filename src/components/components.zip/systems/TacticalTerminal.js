import React, { useEffect, useRef, useState } from 'react';
import { Terminal, Shield, Zap, X } from 'lucide-react';
import { ZaireCard, ZaireHeader } from './DesignSystem';
import { useZaireOS } from '../../engine/ZaireOSContext';

export default function TacticalTerminal() {
  const terminalRef = useRef(null);
  const textRef = useRef(null);
  const { commandLogs, dispatchCommand } = useZaireOS();
  const [input, setInput] = useState('');

  // Auto-scroll to bottom
  useEffect(() => {
    if (textRef.current) {
      textRef.current.scrollTop = textRef.current.scrollHeight;
    }
  }, [commandLogs]);

  const handleCommand = (e) => {
    if (e.key === 'Enter' && input.trim()) {
      e.preventDefault();
      dispatchCommand(input);
      setInput('');
    }
  };

  return (
    <ZaireCard className="h-full" noPadding>
      <ZaireHeader 
        title="Tactical Terminal" 
        icon={Terminal} 
        rightElement={
          <div className="flex items-center gap-2 text-[9px] font-mono text-[#10b981] tracking-widest">
            <span className="w-1.5 h-1.5 bg-[#10b981] rounded-full animate-pulse"></span>
            ROOT
          </div>
        }
      />
      
      <div 
        className="flex-1 p-3 overflow-y-auto bg-[#000000] font-mono text-[11px] flex flex-col gap-1 relative"
        ref={textRef}
        style={{ fontFamily: "'JetBrains Mono', monospace" }}
      >
        {/* Subtle dot grid for the terminal background */}
        <div className="absolute inset-0 opacity-[0.02] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '10px 10px' }}></div>
        
        {commandLogs.map((log) => (
          <div key={log.id} className="relative z-10 flex gap-2">
            <span className="text-[#555] shrink-0">[{new Date(log.id).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'})}]</span>
            {log.sender === 'operator' ? (
              <span className="text-[#00d4ff]">$ {log.text}</span>
            ) : (
              <span className="text-[#a0a0a0] break-words">{log.text}</span>
            )}
          </div>
        ))}
        
        <div className="relative z-10 flex gap-2 mt-1 items-center">
          <span className="text-[#10b981] shrink-0">zaire@root:~$</span>
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleCommand}
            className="flex-1 bg-transparent border-none outline-none text-[#ededed] shadow-none"
            autoFocus
            spellCheck="false"
          />
        </div>
      </div>
    </ZaireCard>
  );
}
