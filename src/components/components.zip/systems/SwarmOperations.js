import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Network, Cpu, ShieldCheck, ChevronRight, X, Terminal, Target, ListChecks, FileCode2 } from 'lucide-react';
import { ZaireCard, ZaireHeader } from './DesignSystem';
import { useZaireOS } from '../../engine/ZaireOSContext';

export default function SwarmOperations() {
  const { agents, setAgents } = useZaireOS();
  const [selectedAgentId, setSelectedAgentId] = useState(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setAgents(prev => prev.map(agent => {
        if (agent.status === 'ACTIVE' || agent.status === 'EXECUTING') {
          const newThought = { time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'}), text: `> EXEC_NODE[0x${Math.floor(Math.random() * 9000).toString(16).toUpperCase()}] OK` };
          return { ...agent, thoughts: [...(agent.thoughts || []), newThought].slice(-5) };
        }
        return agent;
      }));
    }, 2000);
    return () => clearInterval(interval);
  }, [setAgents]);

  const enrichedAgents = agents.map(a => {
    let color = '#3b82f6';
    let icon = Network;
    if (a.id === 'Code Architect') { color = '#00d4ff'; icon = Network; }
    if (a.id === 'Critic Agent') { color = '#94a3b8'; icon = ShieldCheck; }
    if (a.id === 'Executor Agent') { color = '#10b981'; icon = Cpu; }
    if (a.id === 'Planner Agent') { color = '#f59e0b'; icon = Target; }
    
    return { ...a, color, icon, name: a.id };
  });

  const selectedAgent = enrichedAgents.find(a => a.id === selectedAgentId);

  // Is any agent actively working? Add the "thinking" gradient line to the card
  const isSwarmActive = enrichedAgents.some(a => a.status === 'ACTIVE' || a.status === 'EXECUTING');

  return (
    <ZaireCard className={`h-full ${isSwarmActive ? 'thinking' : ''}`} noPadding>
      <ZaireHeader 
        title="Swarm Operations" 
        icon={Network} 
        rightElement={
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-[#10b981] rounded-full"></span>
            <span className="text-[9px] font-mono text-[#10b981] uppercase">Sync: 1ms</span>
          </div>
        }
      />

      <div className="flex-1 overflow-hidden relative bg-[#000000]">
        <AnimatePresence mode="wait">
          {!selectedAgentId ? (
            <motion.div 
              key="list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col h-full overflow-y-auto"
            >
              {/* Header row for density */}
              <div className="grid grid-cols-12 gap-2 px-3 py-2 border-b border-[#1f1f1f] bg-[#0a0a0a] text-[9px] font-mono text-[#666] uppercase tracking-widest">
                <div className="col-span-6">Compute Node</div>
                <div className="col-span-4">Directive</div>
                <div className="col-span-2 text-right">State</div>
              </div>

              {enrichedAgents.map(agent => (
                <motion.div 
                  key={agent.id}
                  layoutId={`agent-card-${agent.id}`}
                  onClick={() => setSelectedAgentId(agent.id)}
                  className="grid grid-cols-12 gap-2 px-3 py-2 border-b border-[#141414] hover:bg-[#0a0a0a] transition-colors items-center cursor-pointer group"
                >
                  <div className="col-span-6 flex items-center gap-2">
                    <div className="w-5 h-5 rounded bg-[#1f1f1f] border border-[#333] flex items-center justify-center">
                      <agent.icon size={10} color={agent.status === 'ACTIVE' || agent.status === 'EXECUTING' ? agent.color : '#666'} />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-[11px] font-mono text-[#ededed] tracking-tight">{agent.name}</span>
                      <span className="text-[8px] font-mono text-[#555]">PID: {Math.floor(Math.random() * 90000)}</span>
                    </div>
                  </div>
                  
                  <div className="col-span-4 flex items-center">
                    <span className="text-[10px] font-sans text-[#a0a0a0] truncate max-w-[100px]">{agent.objective}</span>
                  </div>

                  <div className="col-span-2 flex items-center justify-end gap-2">
                    {agent.status === 'ACTIVE' || agent.status === 'EXECUTING' ? (
                      <span className="text-[9px] font-mono" style={{ color: agent.color }}>RUN</span>
                    ) : (
                      <span className="text-[9px] font-mono text-[#666]">IDLE</span>
                    )}
                    <ChevronRight size={10} className="text-[#333] group-hover:text-[#666] transition-colors" />
                  </div>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div 
              key="details"
              layoutId={`agent-card-${selectedAgent.id}`}
              className="absolute inset-0 bg-[#0a0a0a] flex flex-col z-20 overflow-hidden"
            >
              {/* Detail Header */}
              <div className="p-2 border-b border-[#1f1f1f] flex justify-between items-center bg-[#000000]">
                <div className="flex items-center gap-2 px-2">
                  <selectedAgent.icon size={12} color={selectedAgent.color} />
                  <span className="text-[#ededed] text-[11px] font-mono font-medium">{selectedAgent.name}</span>
                  <span className="text-[#555] text-[9px] font-mono border border-[#333] px-1 rounded bg-[#111]">PID_8492</span>
                </div>
                <button onClick={() => setSelectedAgentId(null)} className="text-[#666] hover:text-[#ededed] transition bg-[#141414] border border-[#222] rounded p-1">
                  <X size={12} />
                </button>
              </div>

              {/* Detail Body */}
              <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-4">
                
                {/* Objective */}
                <div className="flex flex-col gap-1">
                  <div className="text-[9px] text-[#666] font-mono uppercase tracking-widest flex items-center gap-1">
                    <Target size={10} /> Active Directive
                  </div>
                  <div className="text-[12px] text-[#ededed] bg-[#141414] p-2 rounded border border-[#222] font-sans">
                    {selectedAgent.objective}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col gap-1">
                  <div className="text-[9px] text-[#666] font-mono uppercase tracking-widest flex items-center gap-1">
                    <ListChecks size={10} /> Traces
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {(selectedAgent.actions || ['await_io()', 'sys_poll()']).map((act, i) => (
                      <div key={i} className="text-[9px] font-mono text-[#a0a0a0] bg-[#141414] border border-[#222] rounded px-1.5 py-0.5">
                        {act}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Thought Process (Terminal style) */}
                <div className="flex flex-col gap-1 flex-1">
                  <div className="text-[9px] text-[#666] font-mono uppercase tracking-widest flex items-center gap-1">
                    <Terminal size={10} /> stdout
                  </div>
                  <div className="bg-[#000000] rounded p-2 border border-[#1f1f1f] font-mono text-[10px] flex flex-col gap-1 flex-1 overflow-y-auto relative">
                    {/* Deep-space grid background for terminal */}
                    <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '10px 10px' }}></div>
                    
                    {selectedAgent.thoughts.map((t, i) => (
                      <div key={i} className="flex gap-2 relative z-10">
                        <span className="text-[#555] shrink-0">[{t.time}]</span>
                        <span style={{ color: selectedAgent.color }}>{t.text}</span>
                      </div>
                    ))}
                    {(selectedAgent.status === 'ACTIVE' || selectedAgent.status === 'EXECUTING') && (
                      <div className="flex gap-2 relative z-10">
                        <span className="text-[#555]">[{new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'})}]</span>
                        <span className="w-1.5 h-3 animate-pulse" style={{ backgroundColor: selectedAgent.color }}></span>
                      </div>
                    )}
                  </div>
                </div>

              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </ZaireCard>
  );
}
