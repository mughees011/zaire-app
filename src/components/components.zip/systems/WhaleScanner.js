import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Radar, AlertOctagon, ArrowRight, ExternalLink } from 'lucide-react';
import { ZaireCard, ZaireHeader } from './DesignSystem';

const WhaleSonarVisualizer = () => {
  return (
    <div className="h-32 bg-[#000000] border-b border-[#1f1f1f] relative overflow-hidden flex items-center justify-center">
      {/* Intense Sonar Pulse */}
      <motion.div 
        className="absolute w-12 h-12 rounded-full border border-[#ef4444]"
        animate={{ scale: [1, 8], opacity: [1, 0] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeOut" }}
      />
      <motion.div 
        className="absolute w-12 h-12 rounded-full border border-[#ef4444]"
        animate={{ scale: [1, 8], opacity: [1, 0] }}
        transition={{ duration: 2, delay: 1, repeat: Infinity, ease: "easeOut" }}
      />
      
      {/* Central Core */}
      <div className="absolute w-12 h-12 bg-[#ef4444]/20 rounded-full flex items-center justify-center shadow-[0_0_20px_#ef4444]">
        <Radar size={20} className="text-[#ef4444] animate-pulse" />
      </div>

      {/* Floating Particles */}
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1.5 h-1.5 bg-[#f59e0b] rounded-full shadow-[0_0_8px_#f59e0b]"
          initial={{ x: 0, y: 0, opacity: 0 }}
          animate={{ 
            x: (Math.random() - 0.5) * 200, 
            y: (Math.random() - 0.5) * 100, 
            opacity: [0, 1, 0] 
          }}
          transition={{ duration: 3, delay: i * 0.5, repeat: Infinity }}
        />
      ))}
    </div>
  );
};

export default function WhaleScanner() {
  const [alerts, setAlerts] = useState([
    { id: 1, asset: 'BTC', amount: '12,500', value: '$803.1M', from: 'Unknown Wallet', to: 'Binance', type: 'DUMP_WARNING', time: '12s ago' },
    { id: 2, asset: 'ETH', amount: '142,000', value: '$489.9M', from: 'Coinbase', to: 'Cold Storage', type: 'ACCUMULATION', time: '4m ago' },
  ]);

  return (
    <ZaireCard className="h-full border-[#ef4444]/30" noPadding>
      <ZaireHeader 
        title="Whale Scanner" 
        icon={AlertOctagon} 
        rightElement={
          <div className="text-[9px] font-mono text-[#ef4444] bg-[#ef4444]/10 border border-[#ef4444]/20 px-1.5 py-0.5 rounded flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-[#ef4444] rounded-full animate-ping"></span>
            DEFCON 2
          </div>
        }
      />
      
      <WhaleSonarVisualizer />

      <div className="flex-1 overflow-y-auto bg-[#0a0a0a] p-3 flex flex-col gap-3">
        {alerts.map(alert => (
          <motion.div 
            key={alert.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-[#000000] border border-[#ef4444]/30 rounded p-3 relative overflow-hidden"
          >
            <div className="absolute left-0 top-0 bottom-0 w-[2px] bg-[#ef4444]"></div>
            
            <div className="flex justify-between items-center mb-3 pl-2">
              <span className="text-[9px] font-mono bg-[#ef4444]/10 text-[#ef4444] px-1.5 py-0.5 rounded tracking-widest font-bold">
                {alert.type}
              </span>
              <span className="text-[9px] font-mono text-[#666]">{alert.time}</span>
            </div>

            <div className="pl-2 flex items-end gap-3 mb-3">
              <span className="text-[20px] font-bold text-white leading-none">{alert.amount} <span className="text-[#ef4444]">{alert.asset}</span></span>
              <span className="text-[12px] font-mono text-[#888] pb-0.5">({alert.value})</span>
            </div>

            <div className="pl-2 bg-[#111] border border-[#222] rounded p-2 flex items-center justify-between">
              <div className="flex flex-col w-[40%]">
                <span className="text-[8px] text-[#666] font-mono uppercase">Origin</span>
                <span className="text-[10px] text-[#ededed] font-mono truncate">{alert.from}</span>
              </div>
              <ArrowRight size={12} className="text-[#444]" />
              <div className="flex flex-col w-[40%] items-end">
                <span className="text-[8px] text-[#666] font-mono uppercase">Destination</span>
                <span className="text-[10px] text-[#ededed] font-mono truncate">{alert.to}</span>
              </div>
            </div>
            
            <button className="mt-2 w-full flex items-center justify-center gap-1 py-1.5 bg-[#ef4444]/5 hover:bg-[#ef4444]/10 border border-[#ef4444]/20 rounded text-[9px] font-mono text-[#ef4444] transition-colors cursor-pointer">
              <ExternalLink size={10} /> VIEW ON EXPLORER
            </button>
          </motion.div>
        ))}
      </div>
    </ZaireCard>
  );
}
