import React, { useState, useCallback, useMemo, useEffect } from 'react';
import ReactFlow, { 
  Background, 
  Controls, 
  applyNodeChanges, 
  applyEdgeChanges, 
  addEdge,
  MarkerType
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Network, Server, Cpu, Database, Cloud } from 'lucide-react';
import { ZaireCard, ZaireHeader } from './DesignSystem';
import { useZaireOS } from '../../engine/ZaireOSContext';

const initialNodes = [
  { id: 'operator', type: 'agentNode', position: { x: 250, y: 50 }, data: { label: 'Operator', role: 'Command Node', icon: Cloud, color: '#ededed' } },
  { id: 'Code Architect', type: 'agentNode', position: { x: 100, y: 200 }, data: { label: 'Code Architect', role: 'Primary Core', icon: Cpu, color: '#3b82f6' } },
  { id: 'Executor Agent', type: 'agentNode', position: { x: 400, y: 200 }, data: { label: 'Executor Agent', role: 'Execution Subsystem', icon: Server, color: '#10b981' } },
  { id: 'Critic Agent', type: 'agentNode', position: { x: 250, y: 350 }, data: { label: 'Critic Agent', role: 'Review Node', icon: ShieldCheck, color: '#94a3b8' } },
];

const baseEdges = [
  { id: 'e-op-ca', source: 'operator', target: 'Code Architect', style: { stroke: '#333', strokeWidth: 1 } },
  { id: 'e-op-ex', source: 'operator', target: 'Executor Agent', style: { stroke: '#333', strokeWidth: 1 } },
  { id: 'e-ca-cr', source: 'Code Architect', target: 'Critic Agent', style: { stroke: '#333', strokeWidth: 1 } },
  { id: 'e-ex-cr', source: 'Executor Agent', target: 'Critic Agent', style: { stroke: '#333', strokeWidth: 1 } },
];

// Fallback icon for Critic
function ShieldCheck(props) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><path d="m9 12 2 2 4-4"></path></svg>;
}

export default function NeuralGraph() {
  const [nodes, setNodes] = useState(initialNodes);
  const [edges, setEdges] = useState(baseEdges);
  const { neuralEvents, agents } = useZaireOS();

  // Listen to the global swarm agents to update node visual status
  useEffect(() => {
    setNodes(nds => nds.map(node => {
      const globalAgent = agents.find(a => a.id === node.id);
      if (globalAgent) {
        return {
          ...node,
          data: { ...node.data, status: globalAgent.status }
        };
      }
      return node;
    }));
  }, [agents]);

  // Listen to neuralEvents to temporarily animate edges
  useEffect(() => {
    if (neuralEvents.length === 0) {
      setEdges(baseEdges);
      return;
    }

    // Map active events to edges
    const activeEdges = baseEdges.map(edge => {
      const matchingEvent = neuralEvents.find(e => 
        (e.source === edge.source && e.target === edge.target) || 
        (e.source === edge.target && e.target === edge.source)
      );
      
      if (matchingEvent) {
        return {
          ...edge,
          animated: true,
          style: { stroke: '#00d4ff', strokeWidth: 2 },
        };
      }
      return edge;
    });

    setEdges(activeEdges);
  }, [neuralEvents]);

  const onNodesChange = useCallback((changes) => setNodes((nds) => applyNodeChanges(changes, nds)), []);
  const onEdgesChange = useCallback((changes) => setEdges((eds) => applyEdgeChanges(changes, eds)), []);
  const onConnect = useCallback((params) => setEdges((eds) => addEdge({ ...params, animated: true, style: { stroke: '#666' } }, eds)), []);

  const AgentNode = ({ data }) => {
    const Icon = data.icon;
    const isRunning = data.status === 'ACTIVE' || data.status === 'EXECUTING';

    return (
      <div className={`bg-[#0a0a0a] border ${isRunning ? 'border-[#00d4ff]' : 'border-[#1f1f1f]'} rounded p-2 min-w-[120px] shadow-2xl relative overflow-hidden`}>
        {isRunning && (
          <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#00d4ff] to-transparent animate-[scanning-laser_1.5s_infinite]"></div>
        )}
        <div className="flex items-center gap-2 mb-1">
          <Icon size={10} color={isRunning ? data.color : '#666'} />
          <span className="text-[10px] font-mono text-[#ededed] font-medium tracking-tight">{data.label}</span>
        </div>
        <div className="text-[8px] text-[#666] font-mono uppercase tracking-widest">{data.role}</div>
        
        {/* ReactFlow invisible handles */}
        <div className="react-flow__handle react-flow__handle-top" style={{ opacity: 0 }} />
        <div className="react-flow__handle react-flow__handle-bottom" style={{ opacity: 0 }} />
      </div>
    );
  };

  const nodeTypes = useMemo(() => ({ agentNode: AgentNode }), []);

  return (
    <ZaireCard className="h-full" noPadding>
      <ZaireHeader 
        title="Neural Architecture" 
        icon={Network} 
        rightElement={
          <div className="text-[9px] font-mono text-[#00d4ff] tracking-widest border border-[#00d4ff]/30 px-1.5 py-0.5 rounded bg-[#00d4ff]/10">
            LIVE TRACE
          </div>
        }
      />

      <div className="flex-1 w-full relative bg-[#000000]">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          nodeTypes={nodeTypes}
          fitView
          proOptions={{ hideAttribution: true }}
        >
          <Background color="#ffffff" gap={16} size={1} opacity={0.03} />
          {/* Custom controls overrides inside DesignSystem.css */}
          <Controls showInteractive={false} className="opacity-30 hover:opacity-100 transition-opacity" />
        </ReactFlow>
      </div>
    </ZaireCard>
  );
}
