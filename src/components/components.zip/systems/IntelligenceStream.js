import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Globe, AlertTriangle, Zap, ShieldCheck, ChevronDown, Radio } from 'lucide-react';
import { ZaireCard, ZaireHeader } from './DesignSystem';

const MOCK_INTEL = [
  { id: 1, priority: 'CRITICAL', title: 'OpenAI GPT-5 Weights Leak Rumor', impact: 'Systemic market shift.', confidence: 41, source: 'Twitter Alpha Scrape', time: '14m ago' },
  { id: 2, priority: 'HIGH', title: 'Cursor released new pricing', impact: 'Potential threat to ZAIRE Developer tier', confidence: 92, source: 'HackerNews API', time: '2m ago' },
];

export default function IntelligenceStream() {
  const [intelStream, setIntelStream] = useState(MOCK_INTEL);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIntelStream(prev => [{
        id: Date.now(), priority: 'NORMAL', title: 'New Open-Source Vector DB Release', 
        impact: 'Could reduce Memory Vault latency by 40%', confidence: 88, source: 'GitHub Trending', time: 'Just now'
      }, ...prev]);
    }, 6000);
    return () => clearTimeout(timer);
  }, []);

  const getColors = (priority) => {
    switch (priority) {
      case 'CRITICAL': return { bg: 'rgba(239, 68, 68, 0.1)', border: '#ef4444', text: '#ef4444' };
      case 'HIGH': return { bg: 'rgba(245, 158, 11, 0.1)', border: '#f59e0b', text: '#f59e0b' };
      default: return { bg: 'rgba(59, 130, 246, 0.1)', border: '#3b82f6', text: '#3b82f6' };
    }
  };

  return (
    <ZaireCard className="h-full" noPadding>
      <ZaireHeader 
        title="Global Intelligence Stream" 
        icon={Radio} 
        rightElement={
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#f59e0b] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#f59e0b]"></span>
            </span>
            <span className="text-[9px] font-mono text-[#f59e0b] tracking-widest">LIVE RADAR</span>
          </div>
        }
      />

      {/* Radar Visual Header */}
      <div className="h-32 bg-[#000000] border-b border-[#1f1f1f] relative overflow-hidden flex items-center justify-center">
        {/* Radar Rings */}
        <div className="absolute w-64 h-64 border border-[#333] rounded-full opacity-20"></div>
        <div className="absolute w-48 h-48 border border-[#333] rounded-full opacity-40"></div>
        <div className="absolute w-32 h-32 border border-[#333] rounded-full opacity-60"></div>
        <div className="absolute w-16 h-16 border border-[#3b82f6] rounded-full opacity-80 shadow-[0_0_15px_#3b82f6]"></div>
        
        {/* Radar Sweeper */}
        <motion.div 
          className="absolute top-1/2 left-1/2 w-32 h-[1px] origin-left z-10"
          style={{ background: 'linear-gradient(90deg, #3b82f6, transparent)' }}
          animate={{ rotate: 360 }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        ></motion.div>
        
        {/* Radar Dots */}
        <div className="absolute top-1/4 left-1/3 w-1.5 h-1.5 bg-[#ef4444] rounded-full animate-pulse shadow-[0_0_8px_#ef4444]"></div>
        <div className="absolute bottom-1/3 right-1/4 w-1.5 h-1.5 bg-[#f59e0b] rounded-full animate-pulse shadow-[0_0_8px_#f59e0b]"></div>
      </div>

      <div className="flex-1 overflow-y-auto bg-[#0a0a0a] p-3 flex flex-col gap-3 relative">
        <AnimatePresence>
          {intelStream.map((intel) => {
            const colors = getColors(intel.priority);
            return (
              <motion.div
                key={intel.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                className="bg-[#000000] border border-[#1f1f1f] rounded-lg p-3 relative overflow-hidden group"
              >
                {/* Left Accent Bar */}
                <div className="absolute left-0 top-0 bottom-0 w-[2px]" style={{ backgroundColor: colors.border }}></div>

                {/* Header */}
                <div className="flex justify-between items-center pl-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span 
                      className="text-[9px] font-mono font-bold tracking-widest px-1.5 py-0.5 rounded"
                      style={{ backgroundColor: colors.bg, color: colors.text }}
                    >
                      {intel.priority}
                    </span>
                  </div>
                  <span className="text-[9px] font-mono text-[#555]">{intel.time}</span>
                </div>

                {/* Title */}
                <div className="text-[13px] text-[#ededed] font-medium pl-2 leading-snug mb-3">
                  {intel.title}
                </div>

                {/* Complex Data Visual */}
                <div className="pl-2 grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1">
                    <span className="text-[8px] font-mono text-[#666] uppercase tracking-widest">Confidence Index</span>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1 bg-[#1f1f1f] rounded-full overflow-hidden">
                        <motion.div 
                          className="h-full rounded-full" 
                          style={{ backgroundColor: colors.border }}
                          initial={{ width: 0 }}
                          animate={{ width: `${intel.confidence}%` }}
                          transition={{ duration: 1, delay: 0.2 }}
                        />
                      </div>
                      <span className="text-[10px] font-mono text-[#ededed]">{intel.confidence}%</span>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-[8px] font-mono text-[#666] uppercase tracking-widest">Vector Source</span>
                    <span className="text-[10px] text-[#a0a0a0] truncate">{intel.source}</span>
                  </div>
                </div>

                {/* Impact Assessment Box */}
                <div className="mt-3 ml-2 bg-[#111] border border-[#222] p-2 rounded text-[10px] text-[#a0a0a0] flex items-start gap-2">
                  <ShieldCheck size={12} className="text-[#666] shrink-0 mt-0.5" />
                  <span>{intel.impact}</span>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </ZaireCard>
  );
}
