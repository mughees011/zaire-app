import React, { useState } from 'react';
import { Database, Search, Cpu, DatabaseZap, Box } from 'lucide-react';
import { motion } from 'framer-motion';
import { ZaireCard, ZaireHeader } from './DesignSystem';

// Isometric Vector Grid Visualizer
const VectorGrid = () => (
  <div className="h-40 bg-[#000000] border-b border-[#1f1f1f] relative overflow-hidden flex items-center justify-center perspective-[1000px]">
    <motion.div 
      className="relative w-64 h-64 flex flex-wrap gap-1 items-center justify-center"
      style={{ transform: 'rotateX(60deg) rotateZ(45deg)' }}
      animate={{ rotateZ: 360 + 45 }}
      transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
    >
      {[...Array(64)].map((_, i) => (
        <motion.div
          key={i}
          className="w-6 h-6 border border-[#00d4ff]/20 bg-[#00d4ff]/5"
          animate={{ 
            translateZ: Math.random() > 0.8 ? [0, 20, 0] : 0,
            backgroundColor: Math.random() > 0.9 ? 'rgba(0, 212, 255, 0.4)' : 'rgba(0, 212, 255, 0.05)'
          }}
          transition={{ duration: 2, repeat: Infinity, delay: Math.random() * 2 }}
        />
      ))}
      
      {/* Central Core Memory */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-16 h-16 bg-[#a78bfa] blur-2xl opacity-40"></div>
        <div className="w-8 h-8 border-2 border-[#a78bfa] transform -rotate-45 -rotate-x-60 animate-pulse"></div>
      </div>
    </motion.div>
    
    <div className="absolute bottom-2 left-2 flex flex-col gap-1 z-10">
      <span className="text-[8px] font-mono text-[#00d4ff] uppercase tracking-widest">Embedding Space</span>
      <span className="text-[10px] font-mono text-[#ededed]">Dims: 1536</span>
    </div>
  </div>
);

export default function MemoryVault() {
  const [query, setQuery] = useState('');
  
  const memories = [
    { id: 1, type: 'semantic', title: 'React Architecture Specs', tokens: 1420, sim: '98.2%', time: '2h ago' },
    { id: 2, type: 'code', title: 'ZaireOSContext.js Cache', tokens: 840, sim: '92.4%', time: '1h ago' },
    { id: 3, type: 'text', title: 'Operator Instructions', tokens: 310, sim: '87.1%', time: '12m ago' },
  ];

  return (
    <ZaireCard className="h-full border-[#a78bfa]/30" noPadding>
      <ZaireHeader 
        title="Vector Memory Vault" 
        icon={Database} 
        rightElement={
          <div className="text-[9px] font-mono text-[#a78bfa] border border-[#a78bfa]/30 px-1.5 py-0.5 rounded flex items-center gap-1">
            <DatabaseZap size={10} /> INDEXING...
          </div>
        }
      />
      
      <VectorGrid />

      {/* Semantic Search Bar */}
      <div className="p-3 border-b border-[#1f1f1f] bg-[#0a0a0a]">
        <div className="flex items-center bg-[#000000] border border-[#1f1f1f] rounded px-3 py-1.5 focus-within:border-[#a78bfa] transition-colors">
          <Search size={12} className="text-[#666] mr-2" />
          <input 
            type="text" 
            placeholder="Search n-dimensional space..."
            className="bg-transparent border-none outline-none text-[#ededed] text-[11px] font-mono w-full placeholder-[#555]"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Memory Results */}
      <div className="flex-1 overflow-y-auto bg-[#0a0a0a] p-3 flex flex-col gap-2">
        {memories.map(mem => (
          <div key={mem.id} className="bg-[#000000] border border-[#1f1f1f] hover:border-[#333] transition-colors rounded p-2 flex items-center gap-3 group cursor-pointer">
            <div className="w-8 h-8 rounded bg-[#111] border border-[#222] flex items-center justify-center shrink-0">
              {mem.type === 'semantic' ? <Cpu size={12} className="text-[#a78bfa]" /> : 
               mem.type === 'code' ? <Box size={12} className="text-[#00d4ff]" /> : 
               <Database size={12} className="text-[#10b981]" />}
            </div>
            
            <div className="flex-1 min-w-0 flex flex-col justify-center">
              <span className="text-[11px] font-medium text-[#ededed] font-sans truncate">{mem.title}</span>
              <span className="text-[9px] font-mono text-[#666]">Tokens: {mem.tokens}</span>
            </div>
            
            <div className="flex flex-col items-end justify-center shrink-0">
              <span className="text-[10px] font-mono text-[#a78bfa]">{mem.sim}</span>
              <span className="text-[8px] font-mono text-[#555] uppercase tracking-widest">Similarity</span>
            </div>
          </div>
        ))}
      </div>
    </ZaireCard>
  );
}
