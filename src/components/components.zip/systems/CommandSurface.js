import React, { useState, useRef, useEffect } from 'react';
import { TerminalSquare, Circle, Play, SquareTerminal } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { ZaireCard, ZaireHeader, ZaireBadge, ZaireInput } from './DesignSystem';
import { useZaireOS } from '../../engine/ZaireOSContext';

export default function CommandSurface() {
  const [input, setInput] = useState('');
  const { commandLogs, dispatchCommand } = useZaireOS();
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [commandLogs]);

  const handleSend = (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    dispatchCommand(input);
    setInput('');
  };

  return (
    <ZaireCard className="h-full" noPadding>
      <ZaireHeader 
        title="Composer" 
        icon={SquareTerminal} 
        rightElement={<ZaireBadge variant="success" dot>v2.4.1</ZaireBadge>}
      />

      {/* Main Composer Stream Area */}
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-5" style={{ background: '#0a0a0a' }}>
        <AnimatePresence>
          {commandLogs.map(msg => (
            <motion.div 
              key={msg.id} 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-4"
            >
              {/* Identity Column */}
              <div className="shrink-0 mt-0.5 flex flex-col items-center">
                {msg.sender === 'system' ? (
                  <Circle size={10} className="text-[#00d4ff] fill-[#00d4ff]/20" />
                ) : (
                  <Play size={10} className="text-[#888] fill-[#888]" />
                )}
                {/* Connecting line for sequence */}
                <div className="w-[1px] flex-1 bg-[#1f1f1f] mt-2 mb-[-16px]"></div>
              </div>

              {/* Content Column */}
              <div className="flex flex-col gap-1 w-full pb-2">
                <div className="text-[10px] font-mono text-[#555] uppercase tracking-wider flex justify-between">
                  <span>{msg.sender === 'system' ? 'ZAIRE ENGINE' : 'OPERATOR'}</span>
                  <span className="text-[#333]">{new Date(msg.id).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'})}</span>
                </div>
                
                {msg.sender === 'operator' ? (
                  <div className="text-[13px] text-[#ededed] font-medium leading-relaxed font-sans">
                    {msg.text}
                  </div>
                ) : (
                  <div className="text-[12px] text-[#a0a0a0] font-mono leading-relaxed bg-[#000000] border border-[#1f1f1f] p-3 rounded-md mt-1">
                    {msg.text}
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* Input Composer Block */}
      <div style={{ padding: '12px', background: '#000000', borderTop: '1px solid #1f1f1f' }}>
        <form onSubmit={handleSend} className="relative">
          <textarea 
            className="w-full bg-[#0a0a0a] border border-[#1f1f1f] rounded-md text-[#ededed] text-[13px] p-3 pr-10 outline-none font-sans resize-none"
            placeholder="Type a command or describe an outcome..."
            rows={2}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend(e);
              }
            }}
            style={{ transition: 'border-color 0.2s', ':focus': { borderColor: '#444' } }}
          />
          <div className="absolute right-3 bottom-3 flex items-center gap-2">
            <span className="text-[10px] text-[#444] font-mono">⏎ to execute</span>
          </div>
        </form>
      </div>
    </ZaireCard>
  );
}
