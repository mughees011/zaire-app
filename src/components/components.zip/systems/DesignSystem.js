import React from 'react';
import './DesignSystem.css';

// Premium Linear-style Dark Theme Components

export const ZaireCard = ({ children, className = '', noPadding = false }) => (
  <div className={`zaire-card ${noPadding ? 'no-padding' : ''} ${className}`}>
    {children}
  </div>
);

export const ZaireHeader = ({ title, icon: Icon, rightElement }) => (
  <div className="zaire-header">
    <div className="zaire-header-title">
      {Icon && <Icon size={14} className="zaire-header-icon" />}
      {title}
    </div>
    {rightElement && <div>{rightElement}</div>}
  </div>
);

export const ZaireBadge = ({ children, variant = 'default', dot = false }) => (
  <div className={`zaire-badge zaire-badge-${variant}`}>
    {dot && <span className={`zaire-badge-dot ${variant}`}></span>}
    {children}
  </div>
);

export const ZaireInput = ({ icon: Icon, ...props }) => (
  <div className="zaire-input-wrapper">
    {Icon && <Icon size={14} className="zaire-input-icon" />}
    <input className="zaire-input" {...props} />
  </div>
);

export const ZaireButton = ({ children, variant = 'primary', icon: Icon, ...props }) => (
  <button className={`zaire-btn zaire-btn-${variant}`} {...props}>
    {Icon && <Icon size={14} />}
    {children}
  </button>
);

export const ZaireTabs = ({ tabs, activeTab, onChange }) => (
  <div className="zaire-tabs">
    {tabs.map(tab => (
      <button 
        key={tab.id} 
        className={`zaire-tab ${activeTab === tab.id ? 'active' : ''}`}
        onClick={() => onChange(tab.id)}
      >
        {tab.label}
      </button>
    ))}
  </div>
);
