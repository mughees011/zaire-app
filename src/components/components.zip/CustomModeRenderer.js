import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Responsive as ResponsiveGridLayout } from 'react-grid-layout';
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';

import { ZaireOSProvider } from '../engine/ZaireOSContext';
import TacticalTerminal from './systems/TacticalTerminal';
import MarketMatrix from './systems/MarketMatrix';
import WhaleScanner from './systems/WhaleScanner';
import MemoryVault from './systems/MemoryVault';
import CodeStudio from './systems/CodeStudio';
import NeuralGraph from './systems/NeuralGraph';
import CommandSurface from './systems/CommandSurface';
import MissionBoard from './systems/MissionBoard';
import SwarmOperations from './systems/SwarmOperations';
import IntelligenceStream from './systems/IntelligenceStream';
import './CustomModeRenderer.css';

const SystemComponentRegistry = {
  'Tactical Terminal': TacticalTerminal,
  'Market Matrix': MarketMatrix,
  'Whale Scanner': WhaleScanner,
  'Memory Vault': MemoryVault,
  'Code Studio': CodeStudio,
  'Neural Graph': NeuralGraph,
  'Command Surface': CommandSurface,
  'Mission Board': MissionBoard,
  'Swarm Operations': SwarmOperations,
  'Intelligence Stream': IntelligenceStream,
};

const renderPremiumComponent = (compDef) => {
  const PremiumComponent = SystemComponentRegistry[compDef.type];
  if (PremiumComponent) {
    return <PremiumComponent key={compDef.type} />;
  }
  return (
    <div key={compDef.type} className="placeholder-panel">
      <div className="panel-header">{compDef.type.toUpperCase()}</div>
      <div className="panel-body flex-center glass-blur">
        <span className="text-gray-500 font-mono text-[10px]">PREMIUM FALLBACK: {compDef.type}</span>
      </div>
    </div>
  );
};

export default function CustomModeRenderer({ mode }) {
  const [mounted, setMounted] = useState(false);
  const [layout, setLayout] = useState([]);

  useEffect(() => {
    // Generate initial layout for react-grid-layout based on zones
    const newLayout = [];
    let currentY = { left: 0, center: 0, right: 0 };
    
    (mode.components || []).forEach((comp, i) => {
      let x = 4; // center
      let w = 4;
      let h = 10;
      let y = currentY.center;
      
      if (comp.zone === 'Left Sidebar') {
        x = 0; w = 3; y = currentY.left; currentY.left += h;
      } else if (comp.zone === 'Right Inspector') {
        x = 8; w = 4; y = currentY.right; currentY.right += h;
      } else if (comp.zone === 'Main Workspace') {
        x = 3; w = 5; y = currentY.center; currentY.center += h;
      } else if (comp.zone === 'Bottom Console') {
        x = 3; w = 5; y = currentY.center; currentY.center += h; h = 8;
      }

      newLayout.push({ i: comp.type, x, y, w, h, minW: 2, minH: 4 });
    });

    setLayout(newLayout);
    setMounted(false);
    const timer = setTimeout(() => setMounted(true), 100);
    return () => clearTimeout(timer);
  }, [mode?.id, mode?.components]);

  if (!mounted || !mode) return <div className="h-full w-full bg-[#0a0a0a]"></div>;

  return (
    <ZaireOSProvider>
      <div className="custom-mode-layout" style={{ background: '#050505', height: '100%' }}>
        {/* Ambient Glow */}
        <div className="zaire-ambient-bg" style={{ background: `radial-gradient(circle at 50% 50%, ${mode.color || '#00d4ff'}15 0%, rgba(0, 0, 0, 1) 100%)` }}></div>
        
        <ResponsiveGridLayout
          className="layout"
          layouts={{ lg: layout }}
          breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
          cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
          rowHeight={30}
          margin={[20, 20]}
          isDraggable={true}
          isResizable={true}
          draggableHandle=".panel-drag-handle"
          onLayoutChange={(newLayout) => setLayout(newLayout)}
        >
          {mode.components.map(comp => (
            <div key={comp.type} className="react-grid-item-wrapper relative group">
              {/* Invisible drag handle that appears on hover */}
              <div className="panel-drag-handle absolute top-0 left-0 w-full h-4 z-50 cursor-move opacity-0 group-hover:opacity-100 transition-opacity bg-gradient-to-b from-white/10 to-transparent rounded-t-lg"></div>
              {renderPremiumComponent(comp)}
            </div>
          ))}
        </ResponsiveGridLayout>
      </div>
    </ZaireOSProvider>
  );
}
