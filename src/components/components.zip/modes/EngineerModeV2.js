import React, { useState, useEffect, useRef } from 'react';
import { 
  Rocket, Server, Globe, Database, ShieldCheck, Key, Settings, 
  TerminalSquare, Box, Code2, Layout, Smartphone, CheckCircle2, 
  Activity, ArrowRight, Layers, FileCode2, Eye, Cpu, Network, Clock, Play, Terminal, FileText, 
  Search, GitBranch, MonitorPlay, Zap, ExternalLink, Loader2, Cloud, HardDrive, Share2
} from 'lucide-react';
import './EngineerModeV2.css';

const EngineerModeV2 = () => {
  const [activeStage, setActiveStage] = useState(1);
  const [skillLevel, setSkillLevel] = useState('PROFESSIONAL');
  const [projectType, setProjectType] = useState(null);
  const [directiveInput, setDirectiveInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [loadingText, setLoadingText] = useState('');
  const [isTweaking, setIsTweaking] = useState(false);
  const [tweakInput, setTweakInput] = useState('');
  const [cmdSuccess, setCmdSuccess] = useState(false);

  // Live Terminal States
  const [buildLogs, setBuildLogs] = useState([]);
  const [deployLogs, setDeployLogs] = useState([]);
  const buildInterval = useRef(null);
  const deployInterval = useRef(null);

  // Pro Interactive States
  const [activeComponent, setActiveComponent] = useState('HeroSection');
  const [activeFile, setActiveFile] = useState('Hero.tsx');
  const [openFiles, setOpenFiles] = useState(['Hero.tsx', 'server.ts']);

  const fileContents = {
    'Hero.tsx': `export default function Hero() {\n  return (\n    <section className="w-full min-h-screen flex items-center justify-center bg-black">\n      <div className="max-w-4xl mx-auto text-center">\n        <h1 className="text-5xl font-bold text-white mb-6">\n          The Future of Software Assembly\n        </h1>\n        <button className="px-8 py-4 bg-orange-500 text-black font-bold rounded-lg hover:scale-105 transition">\n          Deploy Now\n        </button>\n      </div>\n    </section>\n  );\n}`,
    'Pricing.tsx': `export default function Pricing() {\n  return (\n    <section className="py-20">\n      <h2 className="text-3xl text-center">Pricing</h2>\n      <div className="grid grid-cols-3 gap-8 mt-10">\n         {/* Pricing Cards */}\n      </div>\n    </section>\n  );\n}`,
    'layout.tsx': `export default function RootLayout({ children }) {\n  return (\n    <html lang="en">\n      <body>{children}</body>\n    </html>\n  );\n}`,
    'server.ts': `import { serve } from "bun";\n\nserve({\n  port: 3000,\n  fetch(req) {\n    return new Response("ZAIRE Backend Active");\n  },\n});`
  };

  const openFile = (fileName) => {
    if (!openFiles.includes(fileName)) {
      setOpenFiles([...openFiles, fileName]);
    }
    setActiveFile(fileName);
  };

  const closeFile = (fileName, e) => {
    e.stopPropagation();
    const newFiles = openFiles.filter(f => f !== fileName);
    setOpenFiles(newFiles);
    if (activeFile === fileName) {
      setActiveFile(newFiles[newFiles.length - 1] || null);
    }
  };

  const stages = [
    { num: 1, label: 'MISSION', icon: <Rocket size={12} /> },
    { num: 2, label: 'ARCHITECTURE', icon: <Server size={12} /> },
    { num: 3, label: 'DESIGN', icon: <Layout size={12} /> },
    { num: 4, label: 'BUILD', icon: <Code2 size={12} /> },
    { num: 5, label: 'DEPLOY', icon: <Globe size={12} /> }
  ];

  const projectTypes = [
    { id: 'saas', name: 'SaaS Platform', icon: <Globe size={24} /> },
    { id: 'portfolio', name: 'Portfolio', icon: <Layout size={24} /> },
    { id: 'agent', name: 'AI Agent', icon: <Cpu size={24} /> },
    { id: 'mobile', name: 'Mobile App', icon: <Smartphone size={24} /> },
    { id: 'dashboard', name: 'Dashboard', icon: <Activity size={24} /> },
    { id: 'custom', name: 'Custom Project', icon: <Settings size={24} /> }
  ];

  const currentStack = [
    { role: 'Frontend', tech: 'Next.js', icon: <Globe size={12}/> },
    { role: 'Backend', tech: 'Node.js', icon: <Server size={12}/> },
    { role: 'Database', tech: 'PostgreSQL', icon: <Database size={12}/> },
    { role: 'Auth', tech: 'Clerk', icon: <Key size={12}/> },
    { role: 'Payments', tech: 'LemonSqueezy', icon: <Settings size={12}/> },
  ];

  const proStack = [
    { role: 'Config', tech: 'tsconfig.json', icon: <FileCode2 size={12}/> },
    { role: 'Styles', tech: 'tailwind.config', icon: <FileCode2 size={12}/> },
    { role: 'Env', tech: '.env.local', icon: <Key size={12}/> },
    { role: 'Docker', tech: 'docker-compose', icon: <Box size={12}/> },
    { role: 'CI/CD', tech: '.github/workflows', icon: <Settings size={12}/> },
  ];

  const getAiTeam = () => {
    return [
      { name: 'Architect', status: activeStage === 1 ? 'Running' : 'Complete', active: activeStage === 1, mem: activeStage === 1 ? '84%' : '12%' },
      { name: 'UI Engineer', status: activeStage === 3 ? 'Running' : activeStage > 3 ? 'Complete' : 'Waiting', active: activeStage === 3, mem: activeStage === 3 ? '92%' : '5%' },
      { name: 'Backend', status: activeStage === 4 ? 'Running' : activeStage > 4 ? 'Complete' : 'Waiting', active: activeStage === 4, mem: activeStage === 4 ? '78%' : '2%' },
      { name: 'Security', status: activeStage === 5 ? 'Scanning' : activeStage > 5 ? 'Secure' : 'Pending', active: activeStage === 5, mem: activeStage === 5 ? '64%' : '0%' },
      ...(skillLevel === 'PROFESSIONAL' ? [
        { name: 'DevOps', status: activeStage === 5 ? 'Deploying' : activeStage > 5 ? 'Live' : 'Waiting', active: activeStage === 5, mem: activeStage === 5 ? '88%' : '0%' }, 
        { name: 'QA Engineer', status: activeStage === 4 ? 'Testing' : activeStage > 4 ? 'Passed' : 'Waiting', active: activeStage === 4, mem: activeStage === 4 ? '45%' : '0%' }
      ] : [])
    ];
  };

  const advanceStage = (nextStage, text) => {
    setIsProcessing(true);
    setLoadingText(text);
    setTimeout(() => {
      setIsProcessing(false);
      setActiveStage(nextStage);
    }, 1500);
  };

  const selectProject = (type) => {
    setProjectType(type);
    advanceStage(2, 'Synthesizing Architecture...');
  };

  useEffect(() => {
    if (activeStage === 4 && skillLevel === 'PROFESSIONAL') {
      setBuildLogs(['zaire@system:~$ npm run dev', '> ready - started server on 0.0.0.0:3000']);
      let step = 0;
      const lines = [
        '> event - compiled client and server successfully in 1240 ms',
        '> wait  - compiling...',
        '> event - compiled client and server successfully in 143 ms',
        '> warn  - ./src/components/Hero.tsx: React Hook useEffect has a missing dependency.'
      ];
      buildInterval.current = setInterval(() => {
        if (step < lines.length) {
          setBuildLogs(prev => [...prev, lines[step]]);
          step++;
        } else {
          clearInterval(buildInterval.current);
        }
      }, 800);
    }
    return () => clearInterval(buildInterval.current);
  }, [activeStage, skillLevel]);

  useEffect(() => {
    if (activeStage === 5 && skillLevel === 'PROFESSIONAL') {
      setDeployLogs(['✓ Container pulled successfully from registry (4.2s)']);
      let step = 0;
      const lines = [
        '✓ Dependencies installed matching yarn.lock',
        '✓ Prisma schema pushed to remote PostgreSQL instance',
        'ℹ Running production build (Next.js App Router)...',
        '✓ Compiled successfully in 12.4s',
        '✓ Route cache populated across 12 regions',
        '✓ Traffic routing active',
        'DEPLOYMENT SUCCESS: Edge Network live.'
      ];
      deployInterval.current = setInterval(() => {
        if (step < lines.length) {
          setDeployLogs(prev => [...prev, lines[step]]);
          step++;
        } else {
          clearInterval(deployInterval.current);
        }
      }, 600);
    }
    return () => clearInterval(deployInterval.current);
  }, [activeStage, skillLevel]);

  const handleDirectiveSubmit = () => {
    if (!directiveInput.trim()) return;
    setCmdSuccess(true);
    setTimeout(() => {
      setDirectiveInput('');
      setCmdSuccess(false);
    }, 1000);
  };

  const handleTweak = () => {
    if (!tweakInput.trim()) return;
    setIsTweaking(true);
    setTimeout(() => {
      setIsTweaking(false);
      setTweakInput('');
    }, 2000);
  };

  return (
    <div className="engineer-v2-container">
      <div className="e-cyber-grid"></div>

      {/* TOP ROW: PROJECT COMMAND CENTER */}
      <div className="e-hero-panel">
        <div className="e-hero-title">
          <span className="e-hero-label">PROJECT COMMAND CENTER</span>
          <span className="e-hero-name">ZAIRE SOFTWARE FACTORY</span>
        </div>

        <div className="e-hero-stages">
          {stages.map(s => (
            <div 
              key={s.num} 
              className={`e-stage-step ${activeStage === s.num ? 'active' : activeStage > s.num ? 'completed' : ''}`}
              onClick={() => { if (!isProcessing) setActiveStage(s.num); }}
            >
              <div className="e-stage-icon">
                {activeStage > s.num ? <CheckCircle2 size={12}/> : s.icon}
              </div>
              <span className="e-stage-label">{s.label}</span>
            </div>
          ))}
        </div>

        <div className="e-mode-toggle">
          <button className={`e-toggle-btn ${skillLevel === 'BEGINNER' ? 'active' : ''}`} onClick={() => setSkillLevel('BEGINNER')}>BEGINNER</button>
          <button className={`e-toggle-btn ${skillLevel === 'PROFESSIONAL' ? 'active' : ''}`} onClick={() => setSkillLevel('PROFESSIONAL')}>PROFESSIONAL</button>
        </div>
      </div>

      {/* MIDDLE ROW: WORKSPACE */}
      <div className="e-workspace-row">
        
        {/* LEFT COLUMN: Map & Stack */}
        <div className="e-left-col">
          <div className="e-stack-panel">
            <div className="e-panel-header"><Layers size={10} style={{ color: 'var(--e-primary)' }} /> SYSTEM ARCHITECT</div>
            <div className="e-stack-list">
              {(skillLevel === 'BEGINNER' ? currentStack : [...currentStack, ...proStack]).map((s, i) => (
                <div key={i} className={`e-stack-item ${activeStage >= 2 ? 'e-fade-in' : 'opacity-50'}`} style={{ animationDelay: `${i * 0.05}s` }}>
                  <div className="e-si-left">
                    <span className="e-si-role">{s.role}</span>
                    <span className="e-si-tech">{skillLevel === 'BEGINNER' ? s.role : s.tech}</span>
                  </div>
                  <div className="e-si-icon">{s.icon}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="e-map-panel">
            <div className="e-panel-header"><Network size={10} className="text-purple-400" /> SYSTEM TOPOLOGY</div>
            <div className="e-map-graph">
              <div className={`e-map-node ${activeStage >= 2 ? 'e-glow-node' : ''}`}>Frontend Cluster</div>
              <div className={`e-map-line ${activeStage >= 2 ? 'e-line-active' : ''}`} style={{ top: '30px' }}></div>
              <div className={`e-map-node ${activeStage >= 2 ? 'e-glow-node' : ''}`}>API Gateway</div>
              <div className={`e-map-line ${activeStage >= 2 ? 'e-line-active' : ''}`} style={{ top: '75px' }}></div>
              <div className={`e-map-node ${activeStage >= 2 ? 'e-glow-node' : ''}`}>PostgreSQL Pool</div>
            </div>
          </div>
        </div>

        {/* CENTER COLUMN: Main Dynamic View */}
        <div className="e-center-col">
          
          <div className="e-workspace-area">
            {activeStage === 1 && (
              <div className="e-dynamic-view e-fade-in">
                <div className="e-s1-title">What are you building?</div>
                
                {skillLevel === 'BEGINNER' ? (
                  <div className="e-s1-grid">
                    {projectTypes.map(p => (
                      <button key={p.id} className="e-s1-card relative overflow-hidden group" onClick={() => selectProject(p.id)} disabled={isProcessing}>
                        <div className="e-s1-icon group-hover:scale-110 transition-transform">{p.icon}</div>
                        <span className="e-s1-name">{p.name.toUpperCase()}</span>
                        {isProcessing && projectType === p.id && (
                          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                            <Loader2 className="animate-spin text-[var(--e-primary)]" size={24} />
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                ) : (
                  /* PROFESSIONAL STAGE 1 SETUP: INITIALIZATION MATRIX */
                  <div className="e-pro-matrix e-fade-in">
                    <div className="e-pro-matrix-header">
                      <div className="e-pro-matrix-title">INITIALIZATION MATRIX</div>
                      <div className="e-pro-matrix-subtitle flex items-center gap-2"><Activity size={10} className="animate-pulse"/> ENV: SECURE_CONTAINER_9X</div>
                    </div>
                    <div className="e-pro-setup-grid">
                      <div className="e-pro-box">
                        <div className="e-pro-heading"><Settings size={10}/> REPOSITORY</div>
                        <div className="e-pro-field"><label>Mode</label><select><option>Create New Repo</option><option>Clone Git</option></select></div>
                        <div className="e-pro-field"><label>Name</label><input type="text" defaultValue="zaire-pro-build" /></div>
                        <div className="e-pro-field"><label>Branch</label><select><option>main</option><option>feature-branch</option></select></div>
                      </div>
                      <div className="e-pro-box">
                        <div className="e-pro-heading"><Cpu size={10}/> ZAIRE ENGINE</div>
                        <div className="e-pro-field"><label>Model</label><select><option>Claude 3.5 Sonnet</option><option>GPT-4o</option></select></div>
                        <div className="e-pro-field">
                          <label>Autonomy</label>
                          <div className="e-pro-slider-container"><input type="range" className="e-pro-slider" min="1" max="10" defaultValue="7" /><span className="e-pro-slider-val">7.0</span></div>
                        </div>
                        <div className="e-pro-field"><label>Context</label><select><option>128K Tokens</option><option>256K Tokens</option></select></div>
                      </div>
                      <div className="e-pro-box">
                        <div className="e-pro-heading"><Box size={10}/> BUILD PIPELINE</div>
                        <div className="e-pro-field"><label>Framework</label><select><option>Next.js 14</option><option>Vite React</option></select></div>
                        <div className="e-pro-field"><label>Styling</label><select><option>Tailwind CSS</option><option>CSS Modules</option></select></div>
                        <div className="e-pro-field"><label>Strictness</label><select><option>Strict</option><option>Loose</option></select></div>
                      </div>
                    </div>
                    <button className="e-cmd-btn w-full" onClick={() => advanceStage(2, 'Provisioning Pro Containers...')} disabled={isProcessing}>
                      {isProcessing ? <><Loader2 size={12} className="animate-spin mr-2" /> {loadingText}</> : 'INITIALIZE PROFESSIONAL WORKSPACE'}
                    </button>
                  </div>
                )}
              </div>
            )}

            {activeStage === 2 && (
              <div className="e-dynamic-view e-fade-in">
                {skillLevel === 'BEGINNER' ? (
                  <>
                    <div className="e-s1-title" style={{ fontSize: '20px' }}>System Architecture Locked</div>
                    <p className="text-center text-gray-400 max-w-sm" style={{ fontSize: '11px' }}>ZAIRE has generated the optimal infrastructure blueprint for your project. The Intelligence Engine is standing by.</p>
                    <button className="e-cmd-btn" onClick={() => advanceStage(3, 'Generating UI Blueprints...')} disabled={isProcessing}>
                       {isProcessing ? <><Loader2 size={12} className="animate-spin mr-2" /> {loadingText}</> : 'APPROVE & PROCEED TO DESIGN'}
                    </button>
                  </>
                ) : (
                  /* PROFESSIONAL STAGE 2: ARCHITECTURE MATRIX */
                  <div className="e-pro-arch-matrix e-fade-in">
                    <div className="e-pro-matrix-header mb-2">
                      <div className="e-pro-matrix-title">SYSTEM TOPOLOGY MATRIX</div>
                      <button className="e-cmd-btn" style={{ minWidth: 'auto', padding: '0 12px', height: '24px' }} onClick={() => advanceStage(3, 'Generating Component Tree...')} disabled={isProcessing}>
                        {isProcessing ? <Loader2 size={10} className="animate-spin" /> : 'APPROVE TOPOLOGY'}
                      </button>
                    </div>
                    <div className="e-arch-layer">
                      <div className="e-arch-layer-header"><span>Edge Routing (Vercel)</span> <Globe size={12}/></div>
                      <div className="e-arch-layer-grid">
                        <div className="e-arch-node"><Cloud size={14} className="e-arch-node-icon"/><div className="e-arch-node-text"><span className="e-arch-node-title">CDN</span><span className="e-arch-node-sub">Global Cache</span></div></div>
                        <div className="e-arch-node"><Network size={14} className="e-arch-node-icon"/><div className="e-arch-node-text"><span className="e-arch-node-title">WAF</span><span className="e-arch-node-sub">Security Rules</span></div></div>
                      </div>
                    </div>
                    <div className="e-arch-layer">
                      <div className="e-arch-layer-header"><span>Compute Container (Next.js)</span> <Server size={12}/></div>
                      <div className="e-arch-layer-grid">
                        <div className="e-arch-node"><Cpu size={14} className="e-arch-node-icon"/><div className="e-arch-node-text"><span className="e-arch-node-title">App Router</span><span className="e-arch-node-sub">Server Components</span></div></div>
                        <div className="e-arch-node"><Activity size={14} className="e-arch-node-icon"/><div className="e-arch-node-text"><span className="e-arch-node-title">API Routes</span><span className="e-arch-node-sub">Serverless Fns</span></div></div>
                        <div className="e-arch-node"><Key size={14} className="e-arch-node-icon"/><div className="e-arch-node-text"><span className="e-arch-node-title">Clerk SDK</span><span className="e-arch-node-sub">Auth Middleware</span></div></div>
                      </div>
                    </div>
                    <div className="e-arch-layer">
                      <div className="e-arch-layer-header"><span>Data Persistence (PostgreSQL)</span> <HardDrive size={12}/></div>
                      <div className="e-arch-layer-grid">
                        <div className="e-arch-node"><Database size={14} className="e-arch-node-icon"/><div className="e-arch-node-text"><span className="e-arch-node-title">Connection Pool</span><span className="e-arch-node-sub">PgBouncer</span></div></div>
                        <div className="e-arch-node"><Share2 size={14} className="e-arch-node-icon"/><div className="e-arch-node-text"><span className="e-arch-node-title">Prisma ORM</span><span className="e-arch-node-sub">Client Driver</span></div></div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeStage === 3 && (
              <div className="e-dynamic-view e-fade-in" style={{ justifyContent: 'flex-start' }}>
                <div className="w-full flex justify-between items-center mb-2">
                  <span className="font-mono text-[9px] text-[var(--e-primary)] tracking-widest flex items-center gap-2"><Activity size={10} className="animate-pulse" /> {skillLevel === 'BEGINNER' ? 'VISUAL BLUEPRINTS' : 'COMPONENT TREE INSPECTOR'}</span>
                  <button className="e-cmd-btn" onClick={() => advanceStage(4, 'Compiling Code...')} disabled={isProcessing}>
                    {isProcessing ? <Loader2 size={12} className="animate-spin" /> : 'APPROVE -> BUILD CODE'}
                  </button>
                </div>

                {skillLevel === 'BEGINNER' ? (
                  <div className="w-full flex flex-col gap-4 max-w-2xl mx-auto e-fade-in items-center">
                    <div className="text-center mb-2">
                      <div className="text-[18px] font-bold text-white tracking-wide">Visual Blueprint Generated</div>
                      <p className="text-gray-400 text-[11px] mt-1">ZAIRE has architected the optimal layout. Review the structural mockup below.</p>
                    </div>

                    {/* Glowing Mockup Frame */}
                    <div className="w-full max-w-lg bg-[#0a0a0a] border border-white/10 rounded-xl overflow-hidden shadow-[0_0_40px_rgba(249,115,22,0.1)] relative">
                      <div className="h-6 bg-white/5 border-b border-white/5 flex items-center px-4 gap-1.5">
                        <div className="w-2.5 h-2.5 rounded-full bg-red-500/50"></div>
                        <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50"></div>
                        <div className="w-2.5 h-2.5 rounded-full bg-green-500/50"></div>
                      </div>
                      <div className="p-6 flex flex-col gap-4 opacity-80">
                        {/* Fake Header */}
                        <div className="flex justify-between items-center pb-4 border-b border-white/5">
                          <div className="w-16 h-4 bg-white/20 rounded"></div>
                          <div className="flex gap-4"><div className="w-8 h-2 bg-white/10 rounded"></div><div className="w-8 h-2 bg-white/10 rounded"></div></div>
                        </div>
                        {/* Fake Hero */}
                        <div className="flex flex-col items-center gap-3 py-6">
                          <div className="w-3/4 h-8 bg-white/20 rounded"></div>
                          <div className="w-1/2 h-4 bg-white/10 rounded"></div>
                          <div className="w-24 h-8 bg-[var(--e-primary)] rounded mt-2 shadow-[0_0_15px_var(--e-glow)]"></div>
                        </div>
                        {/* Fake Grid */}
                        <div className="grid grid-cols-3 gap-4 pt-4 border-t border-white/5">
                          <div className="h-16 bg-white/5 rounded border border-white/5"></div>
                          <div className="h-16 bg-white/5 rounded border border-white/5"></div>
                          <div className="h-16 bg-white/5 rounded border border-white/5"></div>
                        </div>
                      </div>
                      
                      {/* Scanning Line overlay */}
                      <div className="absolute top-0 left-0 right-0 h-1 bg-[var(--e-primary)] opacity-50 shadow-[0_0_10px_var(--e-primary)] animate-[scan_3s_linear_infinite]"></div>
                    </div>

                    <div className="w-full max-w-lg flex items-center gap-2 mt-4">
                      <input 
                        type="text" 
                        value={tweakInput}
                        onChange={(e) => setTweakInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleTweak()}
                        className="flex-1 bg-white/5 border border-white/10 rounded px-4 py-2 text-[11px] text-white outline-none focus:border-[var(--e-primary)] transition-colors" 
                        placeholder="Type here to request a design tweak..." 
                        disabled={isTweaking}
                      />
                      <button 
                        onClick={handleTweak}
                        disabled={isTweaking || !tweakInput.trim()}
                        className="bg-white/10 hover:bg-white/20 text-white font-bold w-24 py-2 rounded text-[11px] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center"
                      >
                        {isTweaking ? <Loader2 size={14} className="animate-spin text-[var(--e-primary)]" /> : 'TWEAK'}
                      </button>
                    </div>
                  </div>
                ) : (
                  /* PROFESSIONAL STAGE 3: COMPONENT TREE */
                  <div className="e-pro-design-tree e-fade-in w-full">
                    <div className="e-tree-sidebar">
                      <div className="e-tree-header">App Structure</div>
                      <div className="e-tree-list">
                        <div className={`e-tree-item ${activeComponent === 'RootLayout' ? 'active' : ''}`} onClick={() => setActiveComponent('RootLayout')}><Layout size={10}/> RootLayout</div>
                        <div className={`e-tree-item ${activeComponent === 'HeaderNav' ? 'active' : ''}`} onClick={() => setActiveComponent('HeaderNav')}><Globe size={10}/> HeaderNav</div>
                        <div className={`e-tree-item ${activeComponent === 'HeroSection' ? 'active' : ''}`} onClick={() => setActiveComponent('HeroSection')}><Box size={10}/> HeroSection</div>
                        <div className="e-tree-item pl-6"><Layout size={10}/> Container</div>
                        <div className={`e-tree-item pl-10 ${activeComponent === 'Typography_H1' ? 'active' : ''}`} onClick={() => setActiveComponent('Typography_H1')}><Terminal size={10}/> Typography_H1</div>
                        <div className={`e-tree-item pl-10 ${activeComponent === 'PrimaryCTA' ? 'active' : ''}`} onClick={() => setActiveComponent('PrimaryCTA')}><Play size={10}/> PrimaryCTA</div>
                        <div className={`e-tree-item ${activeComponent === 'PricingMatrix' ? 'active' : ''}`} onClick={() => setActiveComponent('PricingMatrix')}><Box size={10}/> PricingMatrix</div>
                      </div>
                    </div>
                    <div className="e-tree-main">
                      <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.05)] pb-2">
                        <span className="font-mono text-[11px] text-white font-bold">{activeComponent}.tsx</span>
                        <span className="font-mono text-[9px] text-green-400 border border-green-400/30 px-2 py-1 rounded bg-green-400/10">Tailwind + Framer Motion</span>
                      </div>
                      <div className="e-comp-preview">
                        {activeComponent === 'HeroSection' ? (
                          <div className="text-center">
                            <h1 className="text-[20px] font-bold text-white mb-2 tracking-tight">The Future of Assembly</h1>
                            <button className="bg-[var(--e-primary)] text-black font-bold text-[9px] px-4 py-2 rounded">Deploy Now</button>
                          </div>
                        ) : activeComponent === 'PrimaryCTA' ? (
                          <button className="bg-[var(--e-primary)] text-black font-bold text-[12px] px-6 py-3 rounded">Deploy Now</button>
                        ) : activeComponent === 'Typography_H1' ? (
                          <h1 className="text-[24px] font-bold text-white tracking-tight">The Future of Assembly</h1>
                        ) : (
                          <div className="text-gray-500 font-mono text-[10px]">Preview not available for {activeComponent}</div>
                        )}
                      </div>
                      <div className="e-comp-props">
                        <div className="e-comp-prop"><span className="e-prop-key">padding</span><input type="text" className="bg-transparent text-right text-[#10b981] outline-none w-20" defaultValue="py-24 px-6" /></div>
                        <div className="e-comp-prop"><span className="e-prop-key">display</span><input type="text" className="bg-transparent text-right text-[#10b981] outline-none w-32" defaultValue={activeComponent === 'PrimaryCTA' ? 'inline-block' : 'flex-col items-center'} /></div>
                        <div className="e-comp-prop"><span className="e-prop-key">motion</span><input type="text" className="bg-transparent text-right text-[#10b981] outline-none w-24" defaultValue="initial={opacity: 0}" /></div>
                        <div className="e-comp-prop"><span className="e-prop-key">responsive</span><input type="text" className="bg-transparent text-right text-[#10b981] outline-none w-20" defaultValue="md:flex-row" /></div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeStage === 4 && (
              <div className="e-code-view e-fade-in">
                {skillLevel === 'PROFESSIONAL' && (
                  <>
                    <div className="e-code-activity-bar">
                      <div className="e-code-activity-icon active"><FileCode2 size={16} /></div>
                      <div className="e-code-activity-icon"><Search size={16} /></div>
                      <div className="e-code-activity-icon"><GitBranch size={16} /><div className="e-activity-badge">1</div></div>
                      <div className="e-code-activity-icon"><MonitorPlay size={16} /></div>
                      <Settings size={16} className="e-code-activity-icon mt-auto mb-4 hover:rotate-90 transition-transform" />
                    </div>
                    <div className="e-code-sidebar">
                      <div className="e-code-sb-header">EXPLORER <span className="animate-pulse w-1.5 h-1.5 rounded-full bg-[var(--e-primary)]"></span></div>
                      <div className="e-file-tree">
                        <div className="e-file-item text-gray-500">▼ src/</div>
                        <div className="e-file-item pl-4">▼ components/</div>
                        <div className={`e-file-item pl-8 ${activeFile === 'Hero.tsx' ? 'active' : ''}`} onClick={() => openFile('Hero.tsx')}><FileCode2 size={10} className={activeFile === 'Hero.tsx' ? 'text-[var(--e-primary)]' : ''}/> Hero.tsx</div>
                        <div className={`e-file-item pl-8 ${activeFile === 'Pricing.tsx' ? 'active' : ''}`} onClick={() => openFile('Pricing.tsx')}><FileCode2 size={10} className={activeFile === 'Pricing.tsx' ? 'text-[var(--e-primary)]' : ''}/> Pricing.tsx</div>
                        <div className={`e-file-item pl-4 ${activeFile === 'layout.tsx' ? 'active' : ''}`} onClick={() => openFile('layout.tsx')}><FileCode2 size={10} className={activeFile === 'layout.tsx' ? 'text-[var(--e-primary)]' : ''}/> layout.tsx</div>
                        <div className="e-file-item text-gray-500 mt-2">▼ backend/</div>
                        <div className={`e-file-item pl-4 ${activeFile === 'server.ts' ? 'active' : ''}`} onClick={() => openFile('server.ts')}><FileCode2 size={10} className={activeFile === 'server.ts' ? 'text-[var(--e-primary)]' : ''}/> server.ts</div>
                      </div>
                    </div>
                  </>
                )}
                
                <div className="e-code-main">
                  <div className="e-code-header flex justify-between items-center pr-3">
                    <div className="flex">
                      {skillLevel === 'PROFESSIONAL' ? (
                        openFiles.map(file => (
                          <span key={file} className={`e-code-tab ${activeFile === file ? 'active' : ''}`} onClick={() => setActiveFile(file)}>
                            <FileCode2 size={10} className={activeFile === file ? 'text-[var(--e-primary)]' : ''}/> {file} 
                            <span className="e-code-tab-close hover:text-white" onClick={(e) => closeFile(file, e)}>×</span>
                          </span>
                        ))
                      ) : (
                        <span className="e-code-tab active"><FileCode2 size={10} className="text-[var(--e-primary)]"/> Hero.tsx</span>
                      )}
                    </div>
                    <button className="e-cmd-btn" onClick={() => advanceStage(5, 'Initiating Deployment...')} disabled={isProcessing}>
                      {isProcessing ? <Loader2 size={10} className="animate-spin" /> : 'DEPLOY V1.0'}
                    </button>
                  </div>
                  <div className="e-code-content">
                    {activeFile && skillLevel === 'PROFESSIONAL' ? (
                      fileContents[activeFile]
                    ) : (
                      <>
                        <span className="text-gray-500 flex items-center gap-2 mb-2"><Activity size={10} className="animate-pulse text-[var(--e-primary)]" /> // ZAIRE UI Agent is writing code...</span>{'\n'}
                        <span className="text-purple-400">export default function</span> <span className="text-blue-400">Hero</span>() {'{'}{'\n'}
                        {'  '}return ({'\n'}
                        {'    '}&lt;<span className="text-green-400">section</span> className="w-full min-h-screen flex items-center justify-center bg-black"&gt;{'\n'}
                        {'      '}&lt;<span className="text-green-400">div</span> className="max-w-4xl mx-auto text-center"&gt;{'\n'}
                        {'        '}&lt;<span className="text-green-400">h1</span> className="text-5xl font-bold text-white mb-6"&gt;{'\n'}
                        {'          '}The Future of Software Assembly{'\n'}
                        {'        '}&lt;/<span className="text-green-400">h1</span>&gt;{'\n'}
                        {'        '}&lt;<span className="text-green-400">button</span> className="px-8 py-4 bg-orange-500 text-black font-bold rounded-lg"&gt;{'\n'}
                        {'          '}Deploy Now{'\n'}
                        {'        '}&lt;/<span className="text-green-400">button</span>&gt;{'\n'}
                        {'      '}&lt;/<span className="text-green-400">div</span>&gt;{'\n'}
                        {'    '}&lt;/<span className="text-green-400">section</span>&gt;{'\n'}
                        {'  '});{'\n'}
                        {'}'}
                        <span className="animate-pulse ml-1 text-[var(--e-primary)]">|</span>
                      </>
                    )}
                  </div>

                  {skillLevel === 'PROFESSIONAL' && (
                    <div className="e-terminal-pane">
                      <div className="e-term-header">
                        <span className="e-term-tab active">TERMINAL</span>
                        <span className="e-term-tab">OUTPUT</span>
                        <span className="e-term-tab">PROBLEMS <span style={{ color: '#8b949e', background: 'rgba(255,255,255,0.05)', padding: '2px 4px', borderRadius: '4px', fontSize: '8px', marginLeft: '4px'}}>0</span></span>
                      </div>
                      <div className="e-term-body font-mono">
                        {buildLogs.map((log, i) => (
                          <div key={i} className={`e-term-line ${log && log.includes('warn') ? 'e-term-warn' : log && (log.includes('ready') || log.includes('successfully')) ? 'e-term-info' : ''}`}>
                            {log && log.includes('zaire@system') ? <><span className="e-term-prompt">zaire@system:~$</span> npm run dev</> : log}
                          </div>
                        ))}
                        <div className="e-term-line mt-1"><span className="e-term-prompt">zaire@system:~$</span> <span className="animate-pulse">_</span></div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeStage === 5 && (
              <div className="e-dynamic-view e-fade-in">
                {skillLevel === 'BEGINNER' ? (
                  <div className="w-full flex flex-col items-center justify-center gap-8 e-fade-in relative">
                    
                    {/* Glowing Core */}
                    <div className="relative flex justify-center items-center">
                      <div className="absolute w-40 h-40 bg-[var(--e-primary)] rounded-full blur-[80px] opacity-20 animate-pulse"></div>
                      <div className="w-24 h-24 bg-black border border-[rgba(249,115,22,0.3)] rounded-full flex items-center justify-center relative z-10 shadow-[0_0_30px_rgba(249,115,22,0.15)]">
                        <Zap size={36} className="text-[var(--e-primary)]" />
                      </div>
                    </div>
                    
                    <div className="text-center z-10">
                      <div className="text-3xl font-bold text-white tracking-tight mb-2 uppercase">System Online</div>
                      <p className="text-gray-400 text-[12px] max-w-sm mx-auto">Your application has been compiled, containerized, and successfully distributed across the edge network.</p>
                    </div>

                    {/* Glass Dashboard Card */}
                    <div className="w-full max-w-md bg-[rgba(20,20,20,0.6)] border border-white/5 rounded-xl p-6 backdrop-blur-xl flex flex-col gap-6 z-10 shadow-2xl">
                      
                      <div className="flex flex-col items-center bg-black/60 border border-white/5 rounded-lg p-4">
                        <span className="text-[9px] text-gray-500 uppercase font-bold tracking-widest mb-2">Live Production Route</span>
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-[14px] text-white">app.zaire-engine.com</span>
                          <div className="w-6 h-6 bg-[rgba(249,115,22,0.1)] rounded flex items-center justify-center cursor-pointer hover:bg-[rgba(249,115,22,0.2)] transition-colors">
                            <ExternalLink size={10} className="text-[var(--e-primary)]" />
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex justify-between border-t border-white/5 pt-6">
                        <div className="flex flex-col items-center gap-1">
                          <span className="text-[14px] font-mono text-white">12</span>
                          <span className="text-[8px] text-gray-500 uppercase tracking-widest">Edge Regions</span>
                        </div>
                        <div className="w-px h-8 bg-white/5"></div>
                        <div className="flex flex-col items-center gap-1">
                          <span className="text-[14px] font-mono text-white">0ms</span>
                          <span className="text-[8px] text-gray-500 uppercase tracking-widest">Cold Start</span>
                        </div>
                        <div className="w-px h-8 bg-white/5"></div>
                        <div className="flex flex-col items-center gap-1">
                          <span className="text-[14px] font-mono text-green-400 flex items-center gap-1"><CheckCircle2 size={10}/> SECURE</span>
                          <span className="text-[8px] text-gray-500 uppercase tracking-widest">SSL Cert</span>
                        </div>
                      </div>
                      
                    </div>
                  </div>
                ) : (
                  /* PROFESSIONAL STAGE 5: DEPLOYMENT DASHBOARD */
                  <div className="e-pro-deploy-dash e-fade-in">
                    <div className="e-deploy-hero">
                      <div className="e-dh-left">
                        <div className="e-dh-icon"><Zap size={20} className={deployLogs.length >= 7 ? "text-green-400" : "animate-pulse"} /></div>
                        <div className="e-dh-text">
                          <h2>{deployLogs.length >= 7 ? 'PRODUCTION_READY' : 'DEPLOYING_TO_EDGE...'}</h2>
                          <a href="#" className="flex items-center gap-1 hover:text-white transition-colors">app.zaire-software.com <ExternalLink size={10}/></a>
                        </div>
                      </div>
                      <div className="e-dh-right"><button className="e-cmd-btn">MANAGE INFRASTRUCTURE</button></div>
                    </div>

                    <div className="e-deploy-metrics-grid">
                      <div className="e-d-metric-box"><label>Edge Status</label><span className={deployLogs.length >= 7 ? "text-green-400" : "text-yellow-400"}>{deployLogs.length >= 7 ? 'Healthy' : 'Provisioning'}</span></div>
                      <div className="e-d-metric-box"><label>P99 Latency</label><span>{deployLogs.length >= 7 ? '84ms' : '---'}</span></div>
                      <div className="e-d-metric-box"><label>Active Conns</label><span>{deployLogs.length >= 7 ? '1,240' : '0'}</span></div>
                      <div className="e-d-metric-box"><label>Error Rate</label><span className="text-green-400">0.00%</span></div>
                    </div>

                    <div className="e-deploy-logs-box">
                      <div className="e-dl-header flex justify-between"><span>BUILD PIPELINE LOGS (REGION: US-EAST)</span>{deployLogs.length < 7 && <Loader2 size={10} className="animate-spin text-[var(--e-primary)]" />}</div>
                      <div className="e-dl-body">
                        {deployLogs.map((log, i) => (
                          <div key={i} className={log && log.includes('SUCCESS') ? 'mt-2 text-white font-bold' : ''}>
                            {log && log.includes('✓') && <span className="text-green-400">✓ </span>}{log && log.includes('ℹ') && <span className="text-blue-400">ℹ </span>}{log ? log.replace('✓ ', '').replace('ℹ ', '') : ''}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* MISSION DIRECTIVE OMNI-BOX */}
          <div className="e-command-bar relative">
            <input 
              type="text" 
              className={`e-cmd-input transition-colors ${cmdSuccess ? 'bg-[rgba(249,115,22,0.1)] border border-[var(--e-primary)]' : ''}`} 
              placeholder={cmdSuccess ? "Directive Received. Processing..." : "Enter mission directives, changes, or natural language prompts..."} 
              value={directiveInput} 
              onChange={(e) => setDirectiveInput(e.target.value)} 
              onKeyDown={(e) => e.key === 'Enter' && handleDirectiveSubmit()}
              disabled={cmdSuccess}
            />
            <button className="e-cmd-btn group" onClick={handleDirectiveSubmit} disabled={cmdSuccess}>
              {cmdSuccess ? <CheckCircle2 size={12} className="text-green-400" /> : <Play size={12} className="group-hover:scale-110 transition-transform" />}
            </button>
          </div>

        </div>

        {/* RIGHT COLUMN: AI Team & Audit */}
        <div className="e-right-col">
          <div className="e-team-panel">
            <div className="e-panel-header"><Box size={10} className="text-yellow-400" /> AI TEAM STATUS</div>
            <div className="e-team-list">
              {getAiTeam().map((agent, i) => (
                <div key={i} className="e-agent-row group">
                  <div className={`e-agent-avatar transition-colors ${agent.active ? 'bg-[rgba(249,115,22,0.1)] border border-[rgba(249,115,22,0.3)]' : ''}`}>
                    {agent.active ? <Activity size={12} style={{ color: 'var(--e-primary)' }} className="animate-pulse" /> : agent.status === 'Complete' || agent.status === 'Passed' || agent.status === 'Secure' || agent.status === 'Live' ? <CheckCircle2 size={12} className="text-green-400" /> : <TerminalSquare size={12} className="text-gray-500" />}
                  </div>
                  <div className="e-agent-info w-full">
                    <div className="flex justify-between items-center w-full">
                      <span className="e-agent-name group-hover:text-[var(--e-primary)] transition-colors">{agent.name}</span>
                      <span className={`e-agent-status ${agent.active ? 'text-[var(--e-primary)] font-bold' : agent.status === 'Waiting' || agent.status === 'Pending' ? 'text-gray-500' : 'text-green-400'}`}>{agent.status}</span>
                    </div>
                    {skillLevel === 'PROFESSIONAL' && (
                      <div className="e-agent-memory"><div className="e-agent-mem-fill" style={{ width: agent.mem }}></div></div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="e-audit-panel">
            <div className="e-panel-header flex justify-between items-center">
              <span className="flex items-center gap-2"><ShieldCheck size={10} className="text-emerald-400" /> DESIGN AUDITOR</span>
              {activeStage === 3 && <Loader2 size={8} className="animate-spin text-emerald-400" />}
            </div>
            <div className="e-audit-grid">
              <div className={`e-audit-score ${activeStage === 3 ? 'e-pulse-bg' : ''}`}><span className="e-audit-val">{activeStage < 3 ? '--' : '91'}</span><span className="e-audit-label">Accessibility</span>{skillLevel === 'PROFESSIONAL' && (<><div className="e-audit-pro-stat"><span>ARIA Tags</span><span className="e-audit-pro-val text-green-400">{activeStage < 3 ? '-' : '100%'}</span></div><div className="e-audit-pro-stat"><span>Contrast</span><span className="e-audit-pro-val">{activeStage < 3 ? '-' : 'AAA'}</span></div></>)}</div>
              <div className={`e-audit-score ${activeStage === 3 ? 'e-pulse-bg' : ''}`} style={{ animationDelay: '0.1s' }}><span className="e-audit-val">{activeStage < 3 ? '--' : '95'}</span><span className="e-audit-label">Mobile UX</span>{skillLevel === 'PROFESSIONAL' && (<><div className="e-audit-pro-stat"><span>Tap Targets</span><span className="e-audit-pro-val text-green-400">{activeStage < 3 ? '-' : '48px+'}</span></div><div className="e-audit-pro-stat"><span>Viewport</span><span className="e-audit-pro-val">{activeStage < 3 ? '-' : 'Scale 1.0'}</span></div></>)}</div>
              <div className={`e-audit-score ${activeStage === 4 ? 'e-pulse-bg' : ''}`} style={{ animationDelay: '0.2s' }}><span className="e-audit-val text-yellow-400">{activeStage < 4 ? '--' : '89'}</span><span className="e-audit-label">Performance</span>{skillLevel === 'PROFESSIONAL' && (<><div className="e-audit-pro-stat"><span>FCP</span><span className="e-audit-pro-val">{activeStage < 4 ? '-' : '0.8s'}</span></div><div className="e-audit-pro-stat"><span>TTI</span><span className="e-audit-pro-val text-yellow-400">{activeStage < 4 ? '-' : '1.2s'}</span></div></>)}</div>
              <div className={`e-audit-score ${activeStage === 4 ? 'e-pulse-bg' : ''}`} style={{ animationDelay: '0.3s' }}><span className="e-audit-val text-yellow-400">{activeStage < 4 ? '--' : '87'}</span><span className="e-audit-label">Conversion</span>{skillLevel === 'PROFESSIONAL' && (<><div className="e-audit-pro-stat"><span>CTA Count</span><span className="e-audit-pro-val">{activeStage < 4 ? '-' : '2'}</span></div><div className="e-audit-pro-stat"><span>Readability</span><span className="e-audit-pro-val">{activeStage < 4 ? '-' : 'Grade 8'}</span></div></>)}</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default EngineerModeV2;
